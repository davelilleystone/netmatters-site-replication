document.querySelector(".out-of-hours h4").addEventListener("click", function () {
  document.querySelector(".content-container").classList.toggle("show");
});
