<?php

/* 

$host = "localhost";
$db_name = "nm_php_assignment";
$user_name = "user";
$password = "U-UG@f?AU6d23-4";

*/


$host = "localhost";
$db_name = "davelill_php_reflection";
$user_name = "davelill_dave";
$password = "B[co2M6jOK;@";
